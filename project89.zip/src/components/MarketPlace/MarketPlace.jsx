import React from 'react';
import "./MarketPlace.css"
const MarketPlace = () => {
    return (
        <div className='marketPlaceContainer'>
            <h2 className='comingSoonTitle'>Coming Soon Marketplace</h2>
        </div>
    );
};

export default MarketPlace;
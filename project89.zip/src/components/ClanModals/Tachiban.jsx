import React from 'react';

const Tachiban = () => {
    return (
        <div class="modal fade" id="tachiban" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content tairaModal">
      <div class="modal-body">
        <h3 className='modalTitle'>Tachiban</h3>
        <p className="modalDes">
          Lorem ipsum, dolor sit amet consectetur adipisicing elit. Tempora corporis reiciendis iste nihil, culpa omnis obcaecati pariatur nam quasi dicta nemo ipsum repellat veritatis quod, earum quam aliquam nesciunt quis consectetur quae adipisci possimus quaerat! Excepturi praesentium culpa tempore fugiat optio, esse eveniet. Dolor laborum officiis, ullam, exercitationem adipisci quidem amet minima, iusto ut delectus pariatur! Placeat ut a aliquam in praesentium repellendus provident? Labore neque voluptatum molestiae. Enim omnis fugit veritatis, debitis explicabo atque recusandae? Sunt ipsum cum mollitia a autem consectetur quae dolor eveniet repellat doloremque. Culpa illum sit odit alias, temporibus error aspernatur sapiente iusto voluptate asperiores.
        </p>
      </div>
    </div>
  </div>
</div>
    );
};

export default Tachiban;
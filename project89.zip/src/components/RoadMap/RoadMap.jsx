import React from 'react';
import "./RoadMap.css"
const RoadMap = () => {
    return (
        <div className='roadMapContainer'>
            <h2 className='comingSoonTitle'>Coming Soon Roadmap</h2>
        </div>
    );
};

export default RoadMap;
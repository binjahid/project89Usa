import React from 'react';
import "./Mint.css"
const Mint = () => {
    return (
        <div className='mintContainer'>
            <h2 className='comingSoonTitle'>Coming Soon Mint</h2>
        </div>
    );
};

export default Mint;
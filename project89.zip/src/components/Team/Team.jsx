import React from 'react';
import "./Team.css"
const Team = () => {
    return (
        <div className='teamContainer'>
            <h2 className='comingSoonTitle'>Coming Soon Team</h2>
        </div>
    );
};

export default Team;